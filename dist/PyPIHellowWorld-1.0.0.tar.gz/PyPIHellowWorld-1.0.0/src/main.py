from first import *
print("add", add(2, 3))
print("sub", sub(2, 3))